<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/login',[UserController::class,'login'])->name('login');

Route::post('/addusers', [UserController::class, 'store'])->name('users.store');
Route::post('/addcourse', [UserController::class, 'addCourse'])->name('course.add');
Route::get('/admin', [UserController::class, 'adminDashboard'])->name('admin');
Route::post('/enroll', [UserController::class, 'enrollStudent'])->name('student.enroll');
Route::get('/teacher', [UserController::class, 'teacherdashboard'])->name('teacher');
Route::post('/markattendace',[UserController::class, 'markAtten'])->name('mark.atten');
Route::post('/uploadMarks',[UserController::class, 'uploadMarks'])->name('upload.marks');
Route::get('/student', [UserController::class, 'studentDashboard'])->name('student');